name = "python_actr"
version_info = (1, 9, 3)
dev = True
version = '.'.join([str(x) for x in version_info])
if dev:
    version = version + 'dev'
